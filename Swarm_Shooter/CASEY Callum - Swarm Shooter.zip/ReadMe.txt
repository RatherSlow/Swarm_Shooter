https://github.com/RatherSlow/Swarm_Shooter
wasd to move leftclick to shoot at mouse
should work with controller (sticks and triggers for control)
Couldnt seem to get quit to work.